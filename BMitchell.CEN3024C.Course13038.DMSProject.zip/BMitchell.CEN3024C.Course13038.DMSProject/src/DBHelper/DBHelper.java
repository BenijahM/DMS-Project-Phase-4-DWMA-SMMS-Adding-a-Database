package DBHelper;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
		import java.util.ArrayList;

public class DBHelper {
	private final String DATABASE_NAME = "C:\\sqlite\\University.db";
	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;

	public DBHelper() {
		connection = null;
		statement = null;
		resultSet = null;
	}

	private void connect() {
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:" + DATABASE_NAME);
			statement = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void close() {
		try {
			connection.close();
			statement.close();
			if (resultSet != null)
				resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private Object[][] arrayListTo2DArray(ArrayList<ArrayList<Object>> list) {
		Object[][] array = new Object[list.size()][];
		for (int i = 0; i < list.size(); i++) {
			ArrayList<Object> row = list.get(i);
			array[i] = row.toArray(new Object[row.size()]);
		}
		return array;
	}

	protected void execute(String sql) {
		try {
			connect();
			statement.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			close();
		}
	}

	/**
	 * Method: executeQueryToTable
	 * Purpose: Retrieves database records and places them into
	 * a DefaultTableModel for use with a JTable.
	 * Arguments: SQL query and optional parameter values.
	 * Return: DefaultTableModel containing database records.
	 */
	protected DefaultTableModel executeQueryToTable(
			String sql, Object... parameters) {

		DefaultTableModel model = new DefaultTableModel();

		try (Connection connection = JDBC.getConnection();
			 PreparedStatement statement =
					 connection.prepareStatement(sql)) {

			for (int i = 0; i < parameters.length; i++) {
				statement.setObject(i + 1, parameters[i]);
			}

			try (ResultSet resultSet = statement.executeQuery()) {

				ResultSetMetaData metadata =
						resultSet.getMetaData();

				int columnCount = metadata.getColumnCount();

				for (int i = 1; i <= columnCount; i++) {
					model.addColumn(metadata.getColumnName(i));
				}

				while (resultSet.next()) {

					Object[] row = new Object[columnCount];

					for (int i = 1; i <= columnCount; i++) {
						row[i - 1] = resultSet.getObject(i);
					}

					model.addRow(row);
				}
			}

		} catch (SQLException e) {

			System.out.println("Unable to retrieve database table.");
			e.printStackTrace();
		}

		return model;
	}

	/**
	 * Method: executeQuery
	 * Purpose: Executes a SELECT statement and retrieves its results.
	 * Arguments: SQL query and optional parameter values.
	 * Return: ArrayList containing the retrieved database records.
	 */
	protected ArrayList<ArrayList<Object>> executeQuery(
			String sql, Object... parameters) {

		ArrayList<ArrayList<Object>> result = new ArrayList<>();

		try (Connection connection = JDBC.getConnection();
			 PreparedStatement statement =
					 connection.prepareStatement(sql)) {

			for (int i = 0; i < parameters.length; i++) {
				statement.setObject(i + 1, parameters[i]);
			}

			try (ResultSet resultSet = statement.executeQuery()) {

				int columnCount =
						resultSet.getMetaData().getColumnCount();

				while (resultSet.next()) {

					ArrayList<Object> row = new ArrayList<>();

					for (int i = 1; i <= columnCount; i++) {
						row.add(resultSet.getObject(i));
					}

					result.add(row);
				}
			}

		} catch (SQLException e) {

			System.out.println("Database query failed.");
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Method: executeUpdate
	 * Purpose: Executes INSERT, UPDATE, and DELETE statements.
	 * Arguments: SQL query and optional parameter values.
	 * Return: Number of rows affected.
	 */
	protected int executeUpdate(String sql, Object... parameters) {

		try (Connection connection = JDBC.getConnection();
			 PreparedStatement statement =
					 connection.prepareStatement(sql)) {

			for (int i = 0; i < parameters.length; i++) {
				statement.setObject(i + 1, parameters[i]);
			}

			return statement.executeUpdate();

		} catch (SQLException e) {

			System.out.println("Database operation failed.");
			e.printStackTrace();
			return 0;
		}
	}
}