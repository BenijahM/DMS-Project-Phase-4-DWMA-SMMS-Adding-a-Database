/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * November 7,2026
 * Class: SoulMissionRecords
 * Objective: This class represents and manages the collection of Soul
 * Mission Records stored in the database. It provides functionality
 * for organizing and accessing record information used by the DWMA
 * Soul Mission Management System.
 */

package DBHelper;

import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class SoulMissionRecords extends DBHelper {
	private final String TABLE_NAME = "SoulMissionRecords";
	public static final String recordId = "recordId";
	public static final String teamName = "teamName";
	public static final String partnerType = "partnerType";
	public static final String kishinSoulsCollected = "kishinSoulsCollected";
	public static final String witchSoulsCollected = "witchSoulsCollected";
	public static final String trainingLevel = "trainingLevel";
	public static final String activeStatus = "activeStatus";
	public static final String lastMissionDate = "lastMissionDate";

	/** Method: prepareSQL
	 * Purpose: prepares the text of a SQL "select" command.
	 * Return Type: String
	 * Argurments: fields (the fields to be displayed in the output.
	 * 			whatField (field to search for), whatValue (value to search for within whatfield),
	 * 			sort (use ASC or DESC to specify the sorting order), sortField (the field that the
	 * 			data will be sorted by).
	*/
	private String prepareSQL(String fields, String whatField,
							  String whatValue, String sortField, String sort) {

		String query = "SELECT ";
		if (fields == null) {
			query += "*";
		} else {
			query += fields;
		}

		query += " FROM " + TABLE_NAME;
		if (whatField != null && whatValue != null) {
			if (!isValidColumn(whatField)) {
				throw new IllegalArgumentException("Invalid search column.");
			}

			query += " WHERE " + whatField + " = ?";
		}

		if (sort != null && sortField != null) {

			if (!isValidColumn(sortField)) {
				throw new IllegalArgumentException("Invalid sorting column.");
			}

			if (!sort.equalsIgnoreCase("ASC")
					&& !sort.equalsIgnoreCase("DESC")) {
				throw new IllegalArgumentException("Invalid sorting direction.");
			}

			query += " ORDER BY " + sortField + " " + sort.toUpperCase();
		}

		return query;
	}


	/**
	 * Method: insert
	 * Purpose: insert a new record into the database.
	 * Return Type: boolean (returns true if the record is successfully inserted;
	 * otherwise, returns false.)
	 * Arguments: each field listed in the table from the database, in order.
	 */
	public boolean insert(Integer recordId, String teamName, String partnerType,
						  Integer kishinSoulsCollected, Integer witchSoulsCollected,
						  Double trainingLevel, Integer activeStatus,
						  String lastMissionDate) {

		String sql = "INSERT INTO " + TABLE_NAME + " (recordId, teamName, partnerType, "
				+ "kishinSoulsCollected, witchSoulsCollected, " + "trainingLevel, activeStatus, lastMissionDate)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		return super.executeUpdate(sql, recordId, teamName, partnerType,
				kishinSoulsCollected, witchSoulsCollected,
				trainingLevel, activeStatus, lastMissionDate) > 0;
	}


	/**
	 * Method: delete
	 * Purpose: removes a record from the database.
	 * Return Type:  boolean (returns true if the record is successfully inserted;
	 * otherwise, returns false.)
	 * Arguments: the field (key) used to determine if a row should be deleted, and the value that should be removed.
	 */
	public boolean delete(String whatField, String whatValue) {
		if (!isValidColumn(whatField)) {
			System.out.println("Invalid database column.");
			return false;
		}

		String sql = "DELETE FROM " + TABLE_NAME + " WHERE " + whatField + " = ?";
		return super.executeUpdate(sql, whatValue) > 0;
	}

	/**
	 * Method: update
	 * Purpose: update a record into the database.
	 * Return Type:  boolean (returns true if the record is successfully inserted;
	 * otherwise, returns false.)
	 * Arguments: the field (key) used to determine if a row should be updated, and the value that should be updated.
	 */
	public boolean update(String whatField, String whatValue, String whereField, String whereValue) {

		if (!isValidColumn(whatField) || !isValidColumn(whereField)) {
			System.out.println("Invalid database column.");
			return false;
		}

		String sql = "UPDATE " + TABLE_NAME + " SET " + whatField + " = ?" + " WHERE " + whereField + " = ?";
		return super.executeUpdate(sql, whatValue, whereValue) > 0;
	}

	/**
	 * Method: updateRecord
	 * Purpose: Updates all information for an existing Soul Mission record
	 * in the database using its record ID.
	 * Arguments: recordId (ID of the record being updated), teamName,
	 * partnerType, kishinSoulsCollected, witchSoulsCollected,
	 * trainingLevel, activeStatus, and lastMissionDate.
	 * Return: true if the record was successfully updated;
	 * otherwise, false.
	 */
	public boolean updateRecord(Integer recordId, String teamName, String partnerType, Integer kishinSoulsCollected,
								Integer witchSoulsCollected, Double trainingLevel, Integer activeStatus, String lastMissionDate) {

		String sql = "UPDATE " + TABLE_NAME + " SET teamName = ?, partnerType = ?, " +
				"kishinSoulsCollected = ?, witchSoulsCollected = ?, " + "trainingLevel = ?, activeStatus = ?, lastMissionDate = ? " +
				"WHERE recordId = ?";

		return super.executeUpdate(sql, teamName, partnerType, kishinSoulsCollected, witchSoulsCollected,
				trainingLevel, activeStatus, lastMissionDate, recordId) > 0;
	}

	/**
	 * Method: select
	 * Purpose: completes a SQL "select" command.
	 * Return Type: ArrayList<ArrayList<Object> (this means it returns a 2D array of objects, that
	 * 	can be any type.
	 * Arguments: fields (the fields to be displayed in the output), whatField (field to search for within),
	 *  		 whatValue (value to search for within whatField), sort (use ASC or DESC to specify the sorting order),
	 *  		 sortField (the field that the data will be sorted by).
	 */
	public ArrayList<ArrayList<Object>> select(String fields, String whatField, String whatValue, String sortField, String sort) {
		String sql = prepareSQL(fields, whatField, whatValue, sortField, sort);

		if (whatField != null && whatValue != null) {return super.executeQuery(sql, whatValue);}
		return super.executeQuery(sql);
	}


	/**
	 * Method: getExecuteResult
	 * Purpose: performs a search of the database, where String "query" is the SQL command that would be entered
	 * on the command line.
	 * Return Type: ArrayList<ArrayList<Object>> (this means it returns a 2D array of objects, so the data returned
	 * can be any type)
	 * Arguments: query (this is the SQL command that would be entered at the command line for a SQL query.)
	 */
	public ArrayList<ArrayList<Object>> getExecuteResult(String query) {
		return super.executeQuery(query);
	}

	/**
	 * Method: execute
	 * Purpose: performs a SQL command, where String query is the SQL command that would be entered at the command line.
	 * Return Type: void
	 * Arguments: query (his is the SQL command that would be entered at the command line for a SQL query.)
	 */
	public void execute(String query) {
		super.execute(query);
	}

	/**
	 * Method: isValidColumn
	 * Purpose: Checks whether a supplied column name matches one of the
	 * approved columns in the SoulMissionRecords database table.
	 * This prevents invalid column names from being inserted into SQL
	 * statements when performing database searches, updates, and deletions.
	 * Return Type: boolean
	 * Arguments: column (the database column name being checked).
	 * Returns true if the column exists in the approved list;
	 * otherwise, returns false.
	 */
	private boolean isValidColumn(String column) {

		return column != null && (
				column.equals(recordId)
						|| column.equals(teamName)
						|| column.equals(partnerType)
						|| column.equals(kishinSoulsCollected)
						|| column.equals(witchSoulsCollected)
						|| column.equals(trainingLevel)
						|| column.equals(activeStatus)
						|| column.equals(lastMissionDate)
		);
	}

	/**
	 * Method: DefaultTableModel
	 * Purpose: perfroms a search of the database, where String query is the SQL command that
	 * Return Type: DefaultTableModel (uses a vector of vectors (a table) to store data.
	 * Arguments:fields (the fields to be displayed in the output), whatField (field to search for within),
	 * 		 whatValue (value to search for within whatField), sort (use ASC or DESC to specify the sorting order),
	 * 		 sortField (the field that the data will be sorted by).
	 */
	public DefaultTableModel selectToTable(String fields, String whatField, String whatValue, String sortField, String sort) {
		String sql = prepareSQL(fields, whatField, whatValue, sortField, sort);

		if (whatField != null && whatValue != null) {
			return super.executeQueryToTable(sql, whatValue);
		}
		return super.executeQueryToTable(sql);
	}

}