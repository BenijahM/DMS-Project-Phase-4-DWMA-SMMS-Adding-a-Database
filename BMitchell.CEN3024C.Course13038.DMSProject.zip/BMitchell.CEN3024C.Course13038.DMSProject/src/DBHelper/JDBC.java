/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * November 7,2026
 * Class: JDBC
 * Objective: This class manages the connection between the application
 * and the database using Java Database Connectivity (JDBC). It provides
 * the functionality needed to establish and manage database connections
 * so the application can interact with stored information.
 */

package DBHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC {

    // Location of the SQLite database.
    private static final String DATABASE_URL =
            "jdbc:sqlite:C:/sqlite/University.db";

    /**
     * Method: getConnection
     * Purpose: Establishes a reusable connection to the SQLite database.
     * Arguments: None.
     * Return: An active database Connection.
     */
    public static Connection getConnection() throws SQLException {

        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "SQLite JDBC driver could not be found.", e);
        }

        return DriverManager.getConnection(DATABASE_URL);
    }

    /**
     * Method: testConnection
     * Purpose: Tests the database connection.
     * Arguments: None.
     * Return: None.
     */
    public static void testConnection() {

        try (Connection connection = getConnection()) {

            System.out.println(
                    "Successfully connected to University.db!");

        } catch (SQLException e) {

            System.out.println("Database connection failed.");
            e.printStackTrace();
        }
    }

    /**
     * Method: displayRecords
     * Purpose: Retrieves and displays all records from
     * SoulMissionRecords in the command-line interface.
     * Arguments: None.
     * Return: None.
     */
    public static void displayRecords() {

        String query = "SELECT * FROM SoulMissionRecords";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(query)) {

            ResultSetMetaData metadata = result.getMetaData();

            int columnCount = metadata.getColumnCount();

            System.out.println(
                    "\nSoulMissionRecords Table Contents:");


            while (result.next()) {

                for (int i = 1; i <= columnCount; i++) {

                    System.out.print(result.getString(i));

                    if (i < columnCount) {
                        System.out.print(" : ");
                    }
                }

                System.out.println();
            }

        } catch (SQLException e) {

            System.out.println("Database query failed.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        // Test the database connection.
        testConnection();

        // Display all records in the database.
        displayRecords();
    }
}
