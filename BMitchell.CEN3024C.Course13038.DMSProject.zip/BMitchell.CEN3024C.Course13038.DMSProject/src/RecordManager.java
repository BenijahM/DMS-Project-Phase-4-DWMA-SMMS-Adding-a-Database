
/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 17, 2026
 * Class: RecordManager
 * Objective: This class manages SoulMissionRecord objects using the
 * SQLite database. It communicates with the SoulMissionRecords class
 * to add, locate, remove, display, and update records. It also
 * retrieves database records and converts them into SoulMissionRecord
 * objects for use throughout the application.
 */

import DBHelper.SoulMissionRecords;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RecordManager {

    private SoulMissionRecords database;

    // Constructor
    public RecordManager() {
        database = new SoulMissionRecords();
    }

    /**
     * Method: addRecord
     * Purpose: Adds a new record to the SQLite database after checking
     * that the supplied record is valid and its ID does not already exist.
     * Arguments: record (the SoulMissionRecord object to be added).
     * Return: true if the record was successfully inserted; otherwise,
     * false.
     */
    public boolean addRecord(SoulMissionRecord record) {

        if (record == null) {
            return false;
        }

        if (record.getRecordId() <= 0 || containsId(record.getRecordId())) {
            return false;
        }

        if (record.getLastMissionDate() == null) {
            return false;
        }

        return database.insert(
                record.getRecordId(),
                record.getTeamName(),
                record.getPartnerType(),
                record.getKishinSoulsCollected(),
                record.getWitchSoulsCollected(),
                record.getTrainingLevel(),
                record.isActiveStatus() ? 1 : 0,
                record.getLastMissionDate().toString()
        );
    }

    /**
     * Method: deleteRecord
     * Purpose: Deletes a record from the SQLite database using its ID.
     * Arguments: recordId (the ID of the record to be deleted).
     * Return: true if the record was successfully deleted; otherwise,
     * false.
     */
    public boolean deleteRecord(int recordId) {

        return database.delete(
                SoulMissionRecords.recordId,
                String.valueOf(recordId)
        );
    }

    /**
     * Method: updateRecord
     * Purpose: Updates all information for an existing record in the
     * SQLite database using its record ID.
     * Arguments: updatedRecord (the SoulMissionRecord object containing
     * the updated information).
     * Return: true if the record was successfully updated;
     * otherwise, false.
     */
    public boolean updateRecord(SoulMissionRecord updatedRecord) {

        if (updatedRecord == null) {
            return false;
        }

        if (updatedRecord.getLastMissionDate() == null) {
            return false;
        }

        if (!containsId(updatedRecord.getRecordId())) {
            return false;
        }

        return database.updateRecord(
                updatedRecord.getRecordId(),
                updatedRecord.getTeamName(),
                updatedRecord.getPartnerType(),
                updatedRecord.getKishinSoulsCollected(),
                updatedRecord.getWitchSoulsCollected(),
                updatedRecord.getTrainingLevel(),
                updatedRecord.isActiveStatus() ? 1 : 0,
                updatedRecord.getLastMissionDate().toString()
        );
    }

    /**
     * Method: findById
     * Purpose: Searches the SQLite database for a record with the
     * specified record ID.
     * Arguments: recordId (the ID being searched for).
     * Return: The matching SoulMissionRecord object, or null if no
     * matching record is found.
     */
    public SoulMissionRecord findById(int recordId) {

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                SoulMissionRecords.recordId,
                String.valueOf(recordId),
                null,
                null
        );

        if (results.isEmpty()) {
            return null;
        }

        return convertToRecord(results.get(0));
    }

    /**
     * Method: findByTeamName
     * Purpose: Searches the SQLite database for a record with the
     * specified team name.
     * Arguments: teamName (the team name being searched for).
     * Return: The matching SoulMissionRecord object, or null if no
     * matching record is found.
     */
    public SoulMissionRecord findByTeamName(String teamName) {

        if (teamName == null || teamName.trim().isEmpty()) {
            return null;
        }

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                SoulMissionRecords.teamName,
                teamName.trim(),
                null,
                null
        );

        if (results.isEmpty()) {
            return null;
        }

        return convertToRecord(results.get(0));
    }

    /**
     * Method: getAllRecords
     * Purpose: Retrieves all records from the SQLite database and
     * displays their information in aligned columns in the console.
     * Arguments: None.
     * Return: None.
     */
    public void getAllRecords() {

        List<SoulMissionRecord> records = getAllRecordsList();

        if (records.isEmpty()) {
            System.out.println("There are currently no records in the system.");
            return;
        }

        String separator =
                "----------------------------------------------------------------------------------------------------------------";

        System.out.println(separator);

        System.out.printf(
                "%-8s %-24s %-16s %14s %12s %10s %8s %-12s%n",
                "ID",
                "Team Name",
                "Partner Type",
                "Kishin Souls",
                "Witch Souls",
                "Training",
                "Active",
                "Last Mission"
        );

        System.out.println(separator);

        for (SoulMissionRecord record : records) {

            System.out.printf(
                    "%-8s %-24s %-15s %14d %12d %10.1f %8s %-12s%n",
                    record.getRecordId(),
                    formatCell(record.getTeamName(), 24),
                    formatCell(record.getPartnerType(), 16),
                    record.getKishinSoulsCollected(),
                    record.getWitchSoulsCollected(),
                    record.getTrainingLevel(),
                    record.isActiveStatus() ? "true" : "false",
                    record.getLastMissionDate()
            );
        }

        System.out.println(separator);
        System.out.println("Total records displayed: " + records.size());
    }

    /**
     * Method: formatCell
     * Purpose: Limits text to the specified column width so that
     * longer values do not disrupt the console table alignment.
     * Arguments: value (the text being formatted), width (maximum
     * number of characters allowed).
     * Return: The formatted text.
     */
    private String formatCell(String value, int width) {

        if (value == null) {
            return "";
        }

        if (value.length() > width) {
            return value.substring(0, width - 3) + "...";
        }

        return value;
    }

    /**
     * Method: containsId
     * Purpose: Checks whether a record with the specified ID exists
     * in the SQLite database.
     * Arguments: recordId (the ID being checked).
     * Return: true if the record exists; otherwise, false.
     */
    public boolean containsId(int recordId) {
        return findById(recordId) != null;
    }

    /**
     * Method: getRecordCount
     * Purpose: Retrieves the total number of records currently
     * stored in the SQLite database.
     * Arguments: None.
     * Return: The number of records in the database.
     */
    public int getRecordCount() {

        ArrayList<ArrayList<Object>> results = database.select(
                SoulMissionRecords.recordId,
                null,
                null,
                null,
                null
        );

        return results.size();
    }

    /**
     * Method: getAllRecordsList
     * Purpose: Retrieves all records from the SQLite database and
     * converts them into SoulMissionRecord objects for use by the GUI.
     * Arguments: None.
     * Return: A List containing all stored SoulMissionRecord objects.
     */
    public List<SoulMissionRecord> getAllRecordsList() {

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                null,
                null,
                SoulMissionRecords.recordId,
                "ASC"
        );

        List<SoulMissionRecord> records = new ArrayList<>();

        for (ArrayList<Object> row : results) {
            records.add(convertToRecord(row));
        }

        return records;
    }

    /**
     * Method: getRecords
     * Purpose: Retrieves all records from the database.
     * Arguments: None.
     * Return: A List containing all stored SoulMissionRecord objects.
     */
    public List<SoulMissionRecord> getRecords() {
        return getAllRecordsList();
    }

    /**
     * Method: convertToRecord
     * Purpose: Converts a database query result row into a
     * SoulMissionRecord object.
     * Arguments: row (an ArrayList containing the eight database
     * column values).
     * Return: A SoulMissionRecord object containing the database values.
     */
    private SoulMissionRecord convertToRecord(ArrayList<Object> row) {

        return new SoulMissionRecord(
                ((Number) row.get(0)).intValue(),
                String.valueOf(row.get(1)),
                String.valueOf(row.get(2)),
                ((Number) row.get(3)).intValue(),
                ((Number) row.get(4)).intValue(),
                ((Number) row.get(5)).doubleValue(),
                ((Number) row.get(6)).intValue() == 1,
                LocalDate.parse(String.valueOf(row.get(7)))
        );
    }
}
